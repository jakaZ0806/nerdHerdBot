
import * as messageFunctions from './data/messageFunctions';
import * as config from './data/config.json';

const schedule = require('node-schedule');
const Discord = require('discord.js');
const client = new Discord.Client();



client.on('ready', () => {
  console.log('I am ready!');
});

client.on('message', message => {
  if (message.content === 'ping') {
    message.reply('pong');
  }
});

client.on('message', message => {
    console.log(message.content);
    console.log('Hallo @<' + client.user.id + '>');
    if (message.content === ('Hallo <@' + client.user.id + '>')) {
        messageFunctions.sendMessageToChannel(client, 'Hallo <@' + message.author.id + '>!', message.channel.name);
    }
});

//Welcome Message
client.on('serverNewMember',(server, user) => {
	console.log('Greeting new member ' + user.username);
	messageFunctions.sendMessageToChannel(client, 'Willkommen auf dem NerdHerd Discord, @' + user.username + '! Du wirst schnellstmöglich von einem Admin für Zugriff auf alle Channels freigeschaltet.' , 'diesdas')
});

var timedMessage = new schedule.RecurrenceRule();

//0 is Sunday
timedMessage.dayOfWeek = 3;
timedMessage.hour = 20;

//
var askForWeeklyShit = schedule.scheduleJob(timedMessage, function() {
    messageFunctions.sendMessageToChannel(client, '@members: Wer ist am Donnerstag dabei?', 'weeklyshit');
});


client.login(config.clientToken);